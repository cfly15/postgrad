## Theme To Do List

- [X] 3 nav bars (main, fixed, mobile)
- [X] Initial visitor cookie - welcome modal
- [X] Scroll popup on bottom - email signup
- [X] Instagram photos (could be improved)
- [X] Google Analytics
- [X] Setup mailgun email with gmail hack (http://simplyian.com/2015/01/07/Hacking-GMail-to-use-custom-domains-for-free/)
- [X] Pinterest Pin it button on all images (need to fix css)
- [X] Add disqus comments on post pages
- [X] Mailchimp signup form
- [X] Main header nav (with links on sides)
- [X] Social Buttons (font awesome)
- [ ] Main nav at medium media queries

Instagram Info:
  code: 28d4ce9f88144b379df3b895f46a307e
  user id: 190004305 (realitychicblog)
  Client ID: 5f6fa1ed289a448db296bef0e8c82c05
  Secret ID: 19d3a2e33f38437bba60efa9978af81e
  Access Code: 190004305.5f6fa1e.69bc292015a347ec892d39827c9c8ee1

MailChimp Login:
  username: postgradco
  password: Handman21!

Mailgun Login:
  email: cfly15@gmail.com
  password: Handman21
